// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SharpDevelop")]
[assembly: AssemblyDescription("free C# IDE")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SharpDevelop")]
[assembly: AssemblyCopyright("Mike Krueger 2000")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.92.1.1")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
