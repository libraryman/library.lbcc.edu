// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using ICSharpCode.Core.AddIns.Codons;

using ICSharpCode.SharpDevelop.Internal.Project;
using ICSharpCode.Core.Services;
using ICSharpCode.Core.Properties;

namespace ICSharpCode.SharpDevelop.Gui.Dialogs.OptionPanels
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class CompileFileProjectOptions : AbstractOptionPanel
	{
		IProject project;
		
		public override bool ReceiveDialogMessage(DialogMessage message)
		{
			if (message == DialogMessage.OK) {
				FileUtilityService fileUtilityService = (FileUtilityService)ServiceManager.Services.GetService(typeof(FileUtilityService));
				for (int i = 0; i < ((CheckedListBox)ControlDictionary["IncludeFilesCheckedListBox"]).Items.Count; ++i) {
					string name = fileUtilityService.RelativeToAbsolutePath(project.BaseDirectory, "." + Path.DirectorySeparatorChar + ((CheckedListBox)ControlDictionary["IncludeFilesCheckedListBox"]).Items[i].ToString());
					int j = 0;
					while (j < project.ProjectFiles.Count && project.ProjectFiles[j].Name != name) {
						++j;
					}
					if (j < project.ProjectFiles.Count) {
						project.ProjectFiles[j].BuildAction = ((CheckedListBox)ControlDictionary["IncludeFilesCheckedListBox"]).GetItemChecked(i) ? BuildAction.Compile : BuildAction.Nothing;
					} else {
						throw new ApplicationException("File " + name + " not found in " + project.Name);
					}
				}
			}
			return true;
		}
		void SetValues(object sender, EventArgs e)
		{
			this.project = (IProject)((IProperties)CustomizationObject).GetProperty("Project");
			FileUtilityService fileUtilityService = (FileUtilityService)ServiceManager.Services.GetService(typeof(FileUtilityService));
			foreach (ProjectFile info in project.ProjectFiles) {
				if (info.BuildAction == BuildAction.Nothing || info.BuildAction == BuildAction.Compile) {
					((CheckedListBox)ControlDictionary["IncludeFilesCheckedListBox"]).Items.Add(fileUtilityService.AbsoluteToRelativePath(project.BaseDirectory, info.Name).Substring(2), info.BuildAction == BuildAction.Compile ? CheckState.Checked : CheckState.Unchecked);
				}
			}
		}
		
		public CompileFileProjectOptions() : base(Application.StartupPath + @"\..\data\resources\panels\CompileFileProjectOptions.xfrm")
		{
			CustomizationObjectChanged += new EventHandler(SetValues);
		}
	}
}
