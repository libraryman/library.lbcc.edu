// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System.Collections;
using System.Collections.Specialized;

namespace SharpDevelop.Internal.Parser
{
	public interface ICompilationUnit : ICompilationUnitBase
	{
		VariableCollection LookUpTable {
			get;
		}
		
		IUsingCollection Usings {
			get;
		}
		
		AttributeSectionCollection Attributes {
			get;
		}
		
		ClassCollection Classes {
			get;
		}
		
		CommentCollection MiscComments {
			get;
		}
		
		CommentCollection DokuComments {
			get;
		}
		
		TagCollection TagComments {
			get;
		}
	}
}
