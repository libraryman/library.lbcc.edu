// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System;
using System.Diagnostics;

namespace SharpDevelop.Internal.Parser
{
	[Serializable]
	public class DefaultRegion : IRegion
	{
		protected int beginLine = -1;
		protected int endLine = -1;
		protected int beginColumn = -1;
		protected int endColumn = -1;
		
		public virtual int BeginLine {
			get {
				return beginLine;
			}
		}
		
		public virtual int BeginColumn {
			get {
				return beginColumn;
			}
		}
		
		/// <value>
		/// if the end column is == -1 the end line is -1 too
		/// this stands for an unknwon end
		/// </value>
		public virtual int EndColumn {
			get {
				return endColumn;
			}
			set {
				endColumn = value;
			}
		}
		
		/// <value>
		/// if the end line is == -1 the end column is -1 too
		/// this stands for an unknwon end
		/// </value>
		public virtual int EndLine {
			get {
				return endLine;
			}
			set {
				endLine = value;
			}
		}
		
		public DefaultRegion(int beginLine, int beginColumn)
		{
			this.beginLine   = beginLine;
			this.beginColumn = beginColumn;
		}
		
		public DefaultRegion(int beginLine, int beginColumn, int endLine, int endColumn)
		{
			this.beginLine   = beginLine;
			this.beginColumn = beginColumn;
			this.endLine     = endLine;
			this.endColumn   = endColumn;
		}
		
		/// <remarks>
		/// Returns true, if the given coordinates (row, column) are in the region.
		/// This method assumes that for an unknown end the end line is == -1
		/// </remarks>
		public bool IsInside(int row, int column)
		{
			return row >= BeginLine && 
			      (row <= EndLine   || EndLine == -1) &&
			      (row != BeginLine || column >= BeginColumn) &&
			      (row != EndLine   || column <= EndColumn);
		}
		
		public override string ToString()
		{
			return String.Format("[Region: BeginLine = {0}, EndLine = {1}, BeginColumn = {2}, EndColumn = {3}]",
			                     beginLine,
			                     endLine,
			                     beginColumn,
			                     endColumn);
		}
	}
}
