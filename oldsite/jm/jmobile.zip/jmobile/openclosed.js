/*global jQuery */
/*!
* openclosed.js 1.2
*/

var closed = [
    1,
    2,
    3,
    195
];

var timestmp = new Date().setFullYear(new Date().getFullYear(), 0, 1);
var yearFirstDay = Math.floor(timestmp / 86400000);
var today = Math.ceil((new Date().getTime()) / 86400000);
var dayOfYear = today - yearFirstDay;
